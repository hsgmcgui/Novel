<template>
  <div class="genduo">
      <ListItem v-for="(book,index) in booklists.books" :key="index" :book="book" />
  </div>
</template>

<script>
import ListItem from "@/components/ListItem.vue"
export default {
    props: ['booklists'],
    components: {
        ListItem
    },
    created() {
        console.log(11111)
    },
}
</script>

<style>

</style>