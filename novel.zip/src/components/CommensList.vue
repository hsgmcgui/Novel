<template>
  <li class="comments-list">
    <div class="thumb">
      <img
        :src="`http://statics.zhuishushenqi.com${item.author.avatar}`"
        alt=""
      />
    </div>
    <div class="right">
      <div class="name">{{ item.author.nickname }}</div>
      <div class="title">{{ item.title }}</div>
      <div class="score">
        <i class="star-full" v-for="(num, index) in todos1" :key="index"></i>
        <!-- <i class="star-full"></i>
          <i class="star-full"></i>
          <i class="star-full"></i> -->
        <i class="star-empty" v-for="(num, index) in todos2" :key="index"></i>
      </div>
      <div class="content">{{ item.content }}</div>
      <div class="love">
        <span>{{item.likeCount}}觉得有用</span>
      </div>
    </div>
  </li>
</template>

<script>
export default {
  props: ["item"],
  data() {
    return {
      todos1: [],
      todos2: [],
    };
  },
  created() {
    this.gettodos();
  },
  methods: {
    gettodos: function () {
      for (var i = 0; i < this.item.rating; i++) {
        this.todos1.push("1");
      }
      for (var j = 0; j < 5 - this.item.rating; j++) {
        this.todos2.push("2");
      }
    },
  },
};
</script>

<style scoped lang="less">
.comments-list {
  padding-left: 38px;
  padding-bottom: 7px;
  position: relative;
  font-size: 12px;
  color: #999999;
  margin-bottom: 10px;
  border-bottom: 1px solid #ddd;
  .thumb {
    position: absolute;
    left: 0;
    img {
      width: 30px;
      height: 30px;
      border-radius: 50%;
    }
  }
  .right {
    .name {
      color: #a58d5e;
    }
    .title {
      font-weight: 700;
      color: #000;
      height: 17px;
      line-height: 17px;
    }
    .score {
      margin: 5px 0;
      i {
        display: inline-block;
        width: 10.24px;
        height: 10.24px;
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        vertical-align: middle;
        margin: 0 3px;
      }
      .star-full {
        background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAH1UlEQVR4Xu2dXXLTSBDHu2UwtVUkNicgOQHmBIQHbN42e4LNXmCxToA5gcxeYMMJyL5h80A4AeEECSfADlRtEYh6a2y8cRzJtuRRtzTTfslD5PF0/3/dUo/mA0E/XnsAvbZejQdvAfg3erpzgfEzw0Cdgpe/hG/OfOTBSwDOo/Y+Ib6eFzwgfLwVvjn2DQLvAKBorznG+ikCNufFJqBRgy52MTwe+QSBdwCMo/YhIP6eKDLRq0Y4PFAAHPXA9L5Pp8vMqxPu+vQ84FUGWBr9Myo8ywLeALBO9M8Y8CkLeAPAWtHvYRbwAoAs0e9bFvACgEzR71kWcB6APNHvUxZwHoBc0e9RFnAagE2i35cs4DQAG0W/J1nAWQBsRL8PWcBZAKxEvwdZwEkAbEa/61nASQCsRv//WQBeNsJB17X3ZM4BYN73n+Odz7aFcnW+gHMAjKN2DxCf2wZg0h7Ri0Y47BXStlCjTgGQNtvHlm9dzAJOAVBo9F9VBE5lAWcAKDr6r54F3Zo76AwALNHvYBZwAgCu6HcxCzgBAGv0O5YFKg8Ad/S7lgUqD4BI9DuUBSoNgFT0u5QFKg2AaPQ7kgUqC4B09LuSBSoLQCmi34EsUEkAyhL9LmSBSgJQquiveBaoHABli/6qZ4FKAfA1etK6nKztx5LOzKF+jejV3fDtia1X0EW3UzoAzHy+H7XL+zEFLSDaIcAWAOwgwE7RzrDZPgGYPYfOEOgEEM8CjE9uXdY+lW3vAREArokM1CTCPQBq4lRs5z9koAAcIdKx+SsJR2EAmHv119rtB0S4QwA7vomcl+J5ONBkEKSzu5ffPxa1d9FGANwUGVoA2ESAvbwO0O+le4AAjgFohAgntuBYC4Avfz15RBQ0CahFpCKXEdLrcOAJYjza+vPt+1V9TQVg/LL9nAj2fbkvr3JUVf9vbimIcNR4NnyRZEMiAKN+552m8apKntxvkyGa3cHjxf/eAOBL9HQvRnrnlvlqjfFA0m6oNwA4j54cEAZ/q8vc8wBS/Md2+PZw3rIbABS1tMo9d1bPom36dm+xnEx8Bijly5bq+btcPSYIG+Ggv/IZYHbBKGofI+KjclmhvcnlgSW7n6aWgZO3blA3EDzI9aP6pXJ4YMXWtysHggpZa18O17jfizX2PV4JgPGSQlBBVtYQ31i1FgAKQcUAWFP8TAAoBBWBIIP4mQFQCEoOQUbxcwGgEJQUghzi5wZAISgZBJR/B7O1HwKTTNbqQB6EpPH9LL3aCIBpJuj0AWFyAKN+eD2wqfgb3QLmTdU3iLzCT4RLeLOXpxcbZ4DZjyoEedyf7zu2xLeWARSCfELm+ZZN8a0DYBrUTJBH1vW+Y1v8QgBQCNYTM+tVRYhfGAAKQVZ5l19flPiFAqAQ2IGgSPELB0AhyA8BEY0DoO7iJM78LSZ/01oZuKxj5sEwBuwjYsO2AS62Z8S/BbTHscycBQAjklnb/wPQTDFTCJZQyyk+yy1g3laFYHm+4hafHQDNBOkASIgvAoBCcBMCKfHFAFAIriCQFF8UAIXAnEHF97SfdvNhqwLSOuDzCiQiet8Mh6K7qcgD0G9/RsCmi/X8KpvMKWTN7vDequuK/L8oALoSGSBpxW6Rgi+2LQqAbkaRvGmDNwCMo04XECJOg0v3WynLtrn6KZoBdFaxOY42/5RuG5CIAuBzBTATT7oSEAVg3O+QDYqr3kajOxDTQeyHzX7BF0inVRfPRv/rhLtSm0iLAaAVwBU6Sdu32QBrnTbEANCNqObkIRI7kVwSgEOYHP6gH8i5steG58QA0Arg2htBsXcCYgBoBXA9fqUqAREApmf/BB9spDBX2pCqBEQAOI/a+4T42hXxbNiBRL9th8MjG21laUMEAK0AEiQSqgSEAOgcAcKvWUh1/lqCfxrhYJ/bThEARv32Bz2J5LrU5mSPZnf40AsAtAJIllmiEmDPAFoBpMd4jeKHHMvB5nvADoBuIJEOgEQlwA6AVgBL7vIClQA7AGUZAjYTMW4BTQ6h/jFduSx+OIbE5BB+APqdU8mDoI2TaxD0tsI3x/OxaF5PX0LckwTBHDjd7A52OSsBdgCkKgAi+liDoLso/KKzf4JgMoLISSnclQArABKTQIjgUwBxL+tOG9NNLYIeItznjEjuySGsAHBWAHmFXxSbG4Si9wRatI8VAI59hc2CSwToN8Jhz2bkmuqFALqF73DCXAmwAlBkBTATfhsu+ouHI9oCYbKUDerdIkHgrgR4AShgISiH8IsAzUAAxOe24Jq1w71glA2AQhaCEr2qQ9CTmlI9mdoOcc/23EbOBaNsAFitAISFX4x62yBwVgJsANhYCGruj3cgOJCK+FXp3oDwDeLDjQeTGBeMcgKQ+2SRtNG7VYJI/X/jUUXGBaNsAOSpAKomfMqoYubhZc5KgA+ADBWArUEcqQyw6WCSmwBEnbNVw6quCZ8XBCcBGEfpE0GntTz2GuGgX5aoLbIf5oGYgMytIXnfZMalYmy3gJ8PRkfzRksM4hQpbJa200YVjU/uQNDiqnTYADDOmcwHBNwHwCZCfLIF34+KGrbNIobktQaEL3B7nyBoAdCoBnTEOS+QFQBJR+tvJ3tAAfCcDAVAAfDcA56brxlAAfDcA56brxlAAfDcA56brxlAAfDcA56brxlAAfDcA56b/x9iW4i9xBhznQAAAABJRU5ErkJggg==");
      }
      .star-empty {
        background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAALG0lEQVR4Xu2dTXbbRhKAq0BFzrxni8gJQp8gzAksL0xmN8oJYl8gIk5g+gSg5gIjncCaXUgvrJwg9AlMnyCgnPdmrFioeU2KCUyB7GqgfwA0tNGCQP9UfVVd3V3dQGj/vJYAet37tvPgLQD/jX/o3WB6Khg4pODsH9EvCx958BKA63hwQoivswoPCJ8+in658g0C7wCg+Dhc4uF7BAyzyiagpEs3jzG6SnyCwDsAlvHgHBB/ylUy0UU3mj1vAWioBNbjPr3f171Dwsc+xQNeeYC91r+hwjMv4A0AHOvfMOCTF/AGAJb1e+gFvABAxfp98wJeAKBk/Z55gcYDUMT6ffICjQegkPV75AUaDUAZ6/fFCzQagFLW74kXaCwAOqzfBy/QWAC0WL8HXqCRAOi0/qZ7gUYCwLZ+oouVgnftDn65X3zWjaajpu2TNQ4Asd9/jQ9+5yhKrPmL52Q7hOKZpuYLNA6AZTwYA+JLKQCZXT8Fj/GqG83G0rJr9ECjANiV7ZOnj+yOHzdmaKIXaBQARax/A4evXqAxABS1/g0AvnqBxgBQxvp99gKNAKCs9fvsBRoBgA7r30CQxIMrRHwiDeSJGjEjqD0AKtbPOfzxMf7hOEV6KwOgKTOC2gPAtX4i+jWMZscyxYrfffICtQZAt/Vv4PDJC9QaABPW71ssUFsATFm/b16gtgCYtH6fvEAtATBt/T55gVoCYMP6ffECtQPAlvX74gVqBcAf8bP+7Sp7B6WZOSrzftnaAHtdAGjSIbp4GL2Zy8qsyu+VA0Dsyn3u3H6bUtAHoh4B9gGghwA9FaFxVv245XHXBb7MIANx59ACgeaAuAgwnR/cdj5U7e4BJwB8oWSgkAiPASjEtbJL/+m0fuVYgNF6ElAAJoh0Jf67hMMYAGKs/qPz1XdE2COAnm4l75OzTutXjQUY+t/7SBYOFB4EafHw9s93pu4uKgXAfSVDHwBDBGCtuZcVVt77JqzfhBco0ncCuAKgBBHmuuBgAfDxX8+eEAUhAfWJ3CvZtvXb9gLl4cA5Ypo8+vnNr7KydgKwPBu8JIITXeOyrCE6fjdp/VXxAqpyEkMKIlx2T2ev8t7NBSCZDN+6dOOqndw8b2Ls325LkRlB0f7ofE8MH+Fo+nS7zHsA1LaDCvv9ZQXLXxcoW5Pe9/MM5B4A1/Gz54TBv/VWrbc04eoRMAHh3oAWCJ3FQ/jf3FSkvN36VfALX/cJbsU6RQ8A+ySmsZxUMr2iUCoNKX1xFL05z750DwCVo1VKtSs+TETvRHIOAly5ULJic/96fBsOWs+IBBzfFS1T13tH9OmbbSPJjQG4my1lG0YEH2BlwWJ6g0kAOD8AWFRttaxsPzfvrxbAAHopUF8sfK3hwB4ifKurjp3lEETdaDqRxgC6o92/lYxzMYcNILhCuE3qtF5uXDkAIPY5CDphCqmAYjXl1gbHnttPd04DV7tucChSpJVcl3DdAcAYIUh8vH7dBCwiMCdIw1TIVVEfILn6VroQxD4zl+l5XrBhQjA+lVkoOGfceywFQAi5hcAtaqaUL3rFAqCFwB0AJpWvBEALgX0ITCtfGYCiEADSeNdatH2x1qPG5WQQczKfvugNY8xnTwP3ialITAAA593R9EU9xO+2lcvJUKzEqn26poDyC3mAjWhaCMxAUkz5UPgGM3YQmNfdFgK9EBRRftkpdykA1jHBcAIIqw8wKvy1w8GWsFwov9QQkG1/oWi1jQn+EqEr5WsDQBTUQqDg/zKPulS+VgBaCNQBcK187QAUhYCALrt088JWQoe6qvS+sT7e9uC1atpd2YAvrxelg8C8QosMByJ5sUs3T5sOwd3ZxreqybYmlG/EA2yAaCG4bxpVU75RAEoMB430BFVUvnEAWgjWXqCI8oloGQCNtpM49UYjCtvBZSoWw0EKOEHELrecpsQERZV/AHRsI23OSBCYp2SR8/YZUKSYeQNB1ZVvZQjIwuATBHVQvnUARIU+QCDSvz9h+lplqifGfFtuP2uU1oaAsp4g71ADN56w/Zzq4RpXynfiATbKUPEEQkBhNAttK7JMfUk8SDjxjkvlOwVAZTiwcey7jLLz3uUcIHWtfOcAiAZwBAU1vJufkydRBbCdxABZi0kmg98RcK97N7UOrtvqs+Ut4+EIEOJ9dYhvDoSj2Tcm2yEr2ykA3GDJxsUPMkGp/s69Z8F1cOsUAK6QuqOp03aqKn/z/HIyJNm7ruF2KliWmyT4EEZTpUsiZUK39XsSDxfSo987jm3baqNjAAbn0g83E/ynG01PbAlEZz28ALd4SreOtjoFgCeg+n6di3PRhuuZgFMAOGMkEv14FM0uddBuuwxuUozLGMcZANxPtXYo/d7GtqgJOLhBbvZD1ibasa9MZwBwhePSOnQog+PlXM4EnAHAHB/fhdFMyw3iOpRZpAzeTMBdnOMSAMYMgC660UztlGwRLRl8ZxkPLwHhn3urKHiyV0eznQFQhRmAiEOEEE1eS8f0dOyvmupQerYMZwC4HBvvAtCXmTP454eEr0yAcB0PTgjxtUxxrmIdJwCsv/0T/CYTiu7oOEfx2004P6JPkc7DKa76KpPt5ncnANi2itWmU3B4SgQj2c6j2KFDhMlRenOmCwSOt3O13uEEAFvjoority1GJwhJPJhLL3h0lPPgCADzkfHybHhKRGOZxctcpQAhQBgdnc4uZM/u+p03E3Cz5+EEgGQy+E2aMVtwl+z6bPBTSjhW/cycTLkEsAiQxkVAYHk8oHk4mn0va4fu350AwBkTVVfHTCn+/tAAiw7hC5V7kG3HPCqQWAeAGxVzM2XEkvIt0kvVs/YqQsp7VnyCpUP4igMCt88u9j2sA8DZIeOkgbtSfI5HuDqgNJJtWHG8nouZgHUAWOPhnu//3J26iRGwakkiexeTqrDymefJrAPAE8T9LBnGIo6SVxeJGAdAq49Qf16fXH6iVMDuh3NB4Nyp6CI5xD4Ak+F7WYSeTQO/yxwW6dVaNoWEkDsQjLfH7tWQAqn4IIMeEMSMIbOYxPJ8AItwNH2sCURWMdYB4IyFYgYgvgLGXb3j9FR8yaQDwUgWtN2BIDyC0pdS8gPFv1cVxVfGUqS3srba3hOwCgA3CUTcLs5ZtpUJU/wuvlkUQDpWvWljfalFMJZm9TIasVpVBDjn3P6tOv1lVL/3EasAcGYAZTu0eb+o4rfr1wkCp2+2T0FZBYBzXo4jpH3PiCkkAky60Wxctqzs+2IMJ4AR58RvqXot7wlYBYA1AygovY3ij+BmomsX796cX+wqwuHIJAi2ZwJ2AWAcBFXVvw3F7wIBEEVSidY/2wdGrQHAPQiqJE2ii0MIxiYyeTjtWK1NQDqWnm7iFJZ5hrsMrlhs7uPWAGDPADi9cqz47SbqBsHmTMAaAJyDoDLdi/HxAQTPXVm8rH2rZWpIz0svJhXcCpe1L+93mwAU+bLIqs27Vu+KdNjGO6VXFcnegVFrABSZAdRN8dtwFQXB5kzAHgAKMwBdizg2rJ1Th+piUjMBYFyW0DTFb8PBBaGRAOxLjFzP5XHcjaYTjkXV/RkREBOQ2HnMvzfZ4qUY1oaAu/HwMttpF4s4VYFntS6yY1WxkdNAIfhVbtwqkwdDhHT+CP68NLVsWxVFy9ohQPgIX50QBH0ASjpAl7L0MlmZKr9b8wAqjWqftSeBFgB7sq5kTS0AlVSLvUa1ANiTdSVragGopFrsNaoFwJ6sK1lTC0Al1WKvUS0A9mRdyZpaACqpFnuNagGwJ+tK1tQCUEm12GtUC4A9WVeypv8Dxs+56uyd6fwAAAAASUVORK5CYII=")
          no-repeat;
      }
    }
    .content {
      overflow: hidden;
      white-space: normal;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 2;
    }
    .love{
      margin-top: 5px;
      height: 12px;
      span{
        float: right;
      }
    }
  }
}
</style>